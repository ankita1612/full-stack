import winston from "winston";

export const log = winston;

export default { log };
