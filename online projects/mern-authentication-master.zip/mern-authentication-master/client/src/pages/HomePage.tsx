export default function Home() {
  return (
    <div className='container'>
      <p>Check the github repo :</p>
      <a href='https://github.com/flaviuse/mern-authentification' data-test-id='homepage-anchor'>
        https://github.com/flaviuse/mern-authentification
      </a>
    </div>
  );
}
