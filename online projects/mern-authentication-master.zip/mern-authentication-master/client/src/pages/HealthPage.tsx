export default function HealthPage() {
  return <div>App is healthy</div>;
}
